import {say, sayGoodbye, sayHello} from 'tenenger7125-npm-publish-ts'

sayHello()
sayGoodbye()
say('say hi')





# Hello NPM

Print 'Hello, npm!' in the console.
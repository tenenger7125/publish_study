const {say, sayGoodbye, sayHello} = require('tenenger7125-npm-publish-ts')

sayHello()
sayGoodbye()
say('say hi')




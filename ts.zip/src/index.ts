export const sayHello = () => console.log('Hello');
export const sayGoodbye = () => console.log('Goodbye');
export const say = (message: string) => console.log(message);
